---
title: "Sample Product"
description: "This is a sample product description."
image: "/images/uploads/sample.jpg"
link: "https://example.com"
---
